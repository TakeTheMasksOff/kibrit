yii-selectize
=============

Yii Extension for selectize.js

For more information and usage examples visit: http://www.yiiframework.com/extension/yii-selectize/
